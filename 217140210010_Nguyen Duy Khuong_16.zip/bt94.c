#include<stdio.h>
int main(){
    for(int i=1; i<100;i++){
        if(i%2==1 && i!= 5 && i!= 7 && i!= 97){
            printf("%d\n",i);
        }
    }



}