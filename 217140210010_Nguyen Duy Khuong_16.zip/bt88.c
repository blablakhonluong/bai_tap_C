#include<stdio.h>

int main(){
    char a;
    for(int a=65;a<=90;a++){
        printf("%c",a);
    }



}